PreReq:
-------
Ensure OpenDDS is installed properly. Use the next section to install OpenDDS.
NOTE: if OpenDDS has already been installed, the next section can be skipped
------------------------------------------------------------------------------------------------------------
-------------------------------OPENDDS INSTALLATION---------------------------------------------------------
------------------------------------------------------------------------------------------------------------
- Download OpenDDS from github (https://github.com/objectcomputing/OpenDDS)

Use this OpenDDS dockerfile (below) as a help file, and commands, to install OpenDDS
https://hub.docker.com/r/objectcomputing/opendds/dockerfile

a - sudo apt-get update && sudo apt-get install -y \
    cmake \
    curl \
    g++ \
    make \
    libxerces-c-dev \
    libssl-dev \
    perl-base \
    perl-modules \
    git

b - export ACE_CONFIG_OPTION="--doc-group"
c - chmod +x configure
    sudo ./configure --no-debug --optimize --prefix=/usr/local --security ${ACE_CONFIG_OPTION} 
d - ./tools/scripts/show_build_config.pl
e - suod make
f - sudo make install
g - sudo ldconfig
h - source /OpenDDS/setenv.sh
i - sudo cp -a ${MPC_ROOT} /usr/local/share/MPC
j - export ACE_ROOT=/usr/local/share/ace \
    TAO_ROOT=/usr/local/share/tao \
    DDS_ROOT=/usr/local/share/dds \
    MPC_ROOT=/usr/local/share/MPC \
    PATH=".:/usr/local/share/ace/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------

Command to create the Makefile from .mpc
========================================
1 - if the Makefile is *not* already generated, and only .mpc file is available. Run the following command to generate the Makefile (**make sure that the paths in .mpc file are correct**) from .mpc
lnic@lnic-VirtualBox:/dev/dev-tools/dev-tools-standalone/secuirty/source/opendds$ $ACE_ROOT/bin/mpc.pl -features xerces=1 -type make dds-security.mpc 

2 - set source by passing the setenv.sh file , Or export the variables in that .sh to the .bashrc file so that this command doesn't have to be executed each time when the project/terminal is created
lnic@lnic-VirtualBox:/dev/dev-tools/dev-tools-standalone/secuirty/source/opendds$ source ~/dev/OpenDDS/setenv.sh

Build/run the publisher and subscriber binary
===============================================

3 - running the make command should generate the IDL code and build the intermediate files and binaries
lnic@lnic-VirtualBox:/dev/dev-tools/dev-tools-standalone/secuirty/source/opendds$ make -j
This should generate the binary named `opendds_security_test`.

IF for some reason, .mpc file has to be used to regenerate the Makefile,
4 - running the command 1, should generate the Makefile. However, the makefile should be renamed from 'Makefile.dds_security' to `Makefile`. Also note, that if a new Makefile is generated,
some parameters have to be updated , like: 
`LIBSUFFIX     = .so` 
and 
LDLIBS        = -l"OpenDDS_Security$(LIBSUFFIX1)" -l"ACE_XML_Utils$(LIBSUFFIX1)" ..... and all other lib file names in LDLIBS
have to be set.
Also a new parameter `LIBSUFFIX1     = ` has to be added 

If for some reason, IDL code is required to be generated manually/separatly , the following commands can be executed.
(Generate code for IDL seperately, if required) 
----------------------------------------------------
lnic@lnic-VirtualBox:opendds$ ~/dev/security/dds-security-latest/srcCxx$ opendds_idl ShapeType.idl 
lnic@lnic-VirtualBox:opendds$ ~/dev/security/dds-security-latest/srcCxx$ tao_idl --idl-version 4 ShapeTypeTypeSupport.idl

Or
lnic@lnic-VirtualBox:opendds$ ~/dev/security/dds-security-latest/srcCxx$ tao_idl --unknown-annotations ignore -I/usr/include -Sa -St -Sm -Sci -in --idl-version 4 ShapeTypeTypeSupport.idl
and use the flag '--unknown-annotations ignore' to ignore the warnings

Run the publisher and subscriber
==================================
To run the opendds subscriber, the command with the least/default parameters is:
5- lnic@lnic-VirtualBox:/dev/dev-tools/dev-tools-standalone/secuirty/source/opendds$ opendds_security_test -sub OD_OA_OM_OD

To run the opendds publisher, the command with the least/default parameters is:
6- lnic@lnic-VirtualBox:/dev/dev-tools/dev-tools-standalone/secuirty/source/opendds$ opendds_security_test -pub OD_OA_OM_OD

